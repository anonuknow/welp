import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';  // <-- #1 import module
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule } from '@angular/common/http';

import {
	// MatAutocompleteModule,
	// MatButtonModule,
	// MatButtonToggleModule,
	// MatCardModule,
	// MatCheckboxModule,
	// MatChipsModule,
	// MatDatepickerModule,
	// MatDialogModule,
	MatExpansionModule,
	// MatGridListModule,
	MatIconModule,
	// MatInputModule,
	// MatListModule,
	// MatMenuModule,
	// MatNativeDateModule,
	// MatPaginatorModule,
	// MatProgressBarModule,
	MatProgressSpinnerModule,
	// MatRadioModule,
	// MatRippleModule,
	// MatSelectModule,
	// MatSidenavModule,
	// MatSliderModule,
	// MatSlideToggleModule,
	// MatSnackBarModule,
	// MatSortModule,
	// MatTableModule,
	MatTabsModule,
	// MatToolbarModule,
	// MatTooltipModule,
	// MatStepperModule,
} from '@angular/material';
import { HttpModule } from '@angular/http';

import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { BodyComponent } from './body/body.component';

import { GlobalService } from '../services/global.service';

@NgModule({
	declarations: [
		AppComponent,
		HeaderComponent,
		BodyComponent,
	],
	imports: [
		BrowserModule,
		BrowserAnimationsModule,
		MatExpansionModule,
		MatProgressSpinnerModule,
		MatTabsModule,
		MatIconModule,
		HttpModule,
		ReactiveFormsModule,
		HttpClientModule,
	],
	providers: [
		GlobalService,
	],
	bootstrap: [AppComponent]
})
export class AppModule { }
