import { Component } from '@angular/core';

import { GlobalService } from '../../services/global.service';

import { Site } from '../../objects/site';
import { SiteStatus } from '../../objects/site.status';

@Component({
    selector: 'body-comp',
    templateUrl: './body.component.html',
    styleUrls: ['./body.component.scss']
})
export class BodyComponent {
    SiteStatus = SiteStatus;
    constructor(public GlobalService: GlobalService){
    
    }
} 