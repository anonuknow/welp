import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { GlobalService } from '../../services/global.service';

import { Site } from '../../objects/site';
import { SiteStatus } from '../../objects/site.status';

@Component({
	selector: 'header-comp',
	templateUrl: './header.component.html',
	styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
	file: any;
	searchForm: FormGroup;
	constructor(public GlobalService: GlobalService, public http: HttpClient){

	}

	ngOnInit(){
		this.searchForm = new FormGroup({
			name: new FormControl('', [Validators.pattern('^(?!mailto:)(?:(?:http|https|ftp)://)(?:\\S+(?::\\S*)?@)?(?:(?:(?:[1-9]\\d?|1\\d\\d|2[01]\\d|22[0-3])(?:\\.(?:1?\\d{1,2}|2[0-4]\\d|25[0-5])){2}(?:\\.(?:[0-9]\\d?|1\\d\\d|2[0-4]\\d|25[0-4]))|(?:(?:[a-z\\u00a1-\\uffff0-9]+-?)*[a-z\\u00a1-\\uffff0-9]+)(?:\\.(?:[a-z\\u00a1-\\uffff0-9]+-?)*[a-z\\u00a1-\\uffff0-9]+)*(?:\\.(?:[a-z\\u00a1-\\uffff]{2,})))|localhost)(?::\\d{2,5})?(?:(/|\\?|#)[^\\s]*)?$'), Validators.required])
		});
	}

	onSubmit(){
		//console.log(this.searchForm.value);
		for(let item of this.GlobalService.crawlingRequests){
			item.unsubscribe();
		}
		this.GlobalService.crawled = 0;
		this.GlobalService.crawling = 0;
		this.GlobalService.Sites = new Array<Site>();
		this.GlobalService.crawlingRequests = new Array<any>();
		if(this.searchForm.value.name.indexOf('.xml')>-1)
			this.GlobalService.startCrawlXml(this.searchForm.value.name);
		else
			this.GlobalService.startCrawl(this.searchForm.value.name);
	}

	stopCrawler(){
		for(let item of this.GlobalService.crawlingRequests){
			item.unsubscribe();
		}
		this.GlobalService.crawled = this.GlobalService.crawling;
		this.GlobalService.crawlingRequests = new Array<any>();
	}

	uploadFile(event){
		let target = event.target || event.srcElement;
		let file = target.files[0];
		this.readFile(file).then(sites=>{
			for(let site of sites){
				let sitePush = new Site();
				sitePush.link = site;
				sitePush.status = SiteStatus.None;
				this.GlobalService.Sites.push(sitePush);
			}
			this.GlobalService.startSpeedTest();
		},
		err=>{
			console.log(err);
		});
	}

	readFile (file): Promise<Array<string>>{
		return new Promise((resolve, reject) => {
			let fileReader = new FileReader();
			fileReader.onload = function(fileLoadedEvent:any){
				let textFromFileLoaded = fileLoadedEvent.target.result;
				let sites: Array<string> = textFromFileLoaded.split("\n");
				resolve(sites);
			};
			fileReader.onerror = function(){
				reject(false);
			};
			fileReader.readAsText(file, "UTF-8");
		});
	}
}