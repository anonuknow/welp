export enum SiteStatus {
    None,
    Loaded,
    Loading
}