import { SiteStatus } from './site.status';
export class Site{
    link: string;
    status: SiteStatus;
    gtmetrixResult: Object;
    googleResult: Object;
    googleResultMobile: Object;
    pingdomResults: Object;
    friendlyResults: Object;
    foundOn: string;
}