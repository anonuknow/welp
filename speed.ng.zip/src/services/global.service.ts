import { Injectable } from '@angular/core';
import { Http, Headers } from '@angular/http';

import { Site } from '../objects/site';
import { SiteStatus } from '../objects/site.status';
import { parseString } from 'xml2js';
@Injectable()
export class GlobalService{
	Sites: Array<Site>;
	sitesLength: number;
	index: number;
	googleApiKey: string = "AIzaSyB2q4MxtTjB9G-EQj9Hfwn3D0L5xBOk4Ug";
	crawlWebsite: string = 'http://speedtest.evonomix.biz/crawler/';
	crawled: number = 0;
	crawling: number = 0;
	crawlingRequests: Array<any>;
	constructor(private Http: Http){
		this.Sites = new Array<Site>();
		this.crawlingRequests = new Array<any>();
	}

	startSpeedTest(){
		this.sitesLength = this.Sites.length;
		this.index = 2;
		this.crawled = 0;
		this.crawling = 0;
		if(this.sitesLength){
			this.requestSite(this.Sites[0]);
			this.requestSite(this.Sites[1]);
			//this.mobileFriendly(this.Sites[0], 0);
		}
	}

	startCrawl(url: string){
		this.crawling++;
		this.crawlingRequests.push(
			this.Http.get(this.crawlWebsite + '?timestamp='+(new Date().getTime())+'&url=' + encodeURIComponent(url)).subscribe(res => {
				let result = res.json();
				for (let item of result) {
					// stop if url exist or item is a file
					if(this.Sites.filter(site => site.link === item.url).length || item.url.split('/').slice(-1)[0].indexOf('.')>-1) continue;

					// push site in the list
					let sitePush = new Site();
					sitePush.link = item.url;
					sitePush.foundOn = item.foundon;
					sitePush.status = SiteStatus.None;
					this.Sites.push(sitePush);

					// crawl founded url
					this.startCrawl(item.url);
				}
				this.crawled++;
			},
			err => {
				this.crawled++;
			})
		);
	}

	startCrawlXml(url: string){
		this.Http.get(url).subscribe(sites=>{
			console.log(sites.text());
			parseString(sites.text(), (err,data)=>{
				//console.log(data);
				for(let site of data.urlset.url){
					let sitePush = new Site();
					sitePush.link = site.loc[0];
					sitePush.status = SiteStatus.None;
					this.Sites.push(sitePush);
					console.log(sitePush);
				}
				this.startSpeedTest();
			});

		},
		err=>{
			console.log(err);
		});
	}

	mobileFriendly(site: Site, index){
		let headers = new Headers({ 'Content-Type': 'application/json'});
		this.Http.post("https://searchconsole.googleapis.com/v1/urlTestingTools/mobileFriendlyTest:run?key=" + this.googleApiKey,{url: site.link}, { headers: headers }).subscribe(
			result => {
				let res = result.json();
				console.log(res);
				if(res.mobileFriendliness == 'MOBILE_FRIENDLY')
					site.friendlyResults = 1;
				else
					site.friendlyResults = 0;
				if(this.sitesLength > index+1){
					setTimeout(()=>{
						this.mobileFriendly(this.Sites[index+1], index+1);
					}, 2001);
				}
			},
			err => {
				site.friendlyResults = 2;
				if(this.sitesLength > index+1){
					setTimeout(()=>{
						this.mobileFriendly(this.Sites[index+1], index+1);
					}, 2001);
				}
			}
		);
	}

	requestSite(site: Site, queue: boolean = true){
		if(!site) return;
		site.status = SiteStatus.Loading;

		let p1 = new Promise((resolve, reject)=>{
			let headers = new Headers({ 'Content-Type': 'application/json'});
			this.Http.get("https://www.googleapis.com/pagespeedonline/v4/runPagespeed?url=" + site.link + "&key=" + this.googleApiKey, { headers: headers }).subscribe(
				result => {
					let res = result.json();
					let formattedResult: any = {};
					formattedResult.title = res.title;
					formattedResult.site = res.id;
					formattedResult.speed = res.ruleGroups.SPEED.score;
					formattedResult.responseCode = res.responseCode;

					let results: Array<any> = new Array<any>();

					for(let rule of Object.values(res.formattedResults.ruleResults)){
						results.push({
							'localizedRuleName':rule['localizedRuleName'],
							'ruleImpact':rule['ruleImpact'],
						});
					}
					formattedResult.results = results;

					site.googleResult = formattedResult;

					resolve(true);
				},
				err => {
					site.googleResult = false;
					resolve(false);
				}
			);
		});

		let p2 = new Promise((resolve, reject)=>{
			let headers = new Headers({ 'Content-Type': 'application/json'});
			this.Http.get("https://www.googleapis.com/pagespeedonline/v4/runPagespeed?url=" + site.link + "&strategy=mobile&key=" + this.googleApiKey, { headers: headers }).subscribe(
				result => {
					let res = result.json();
					let formattedResult: any = {};
					formattedResult.title = res.title;
					formattedResult.site = res.id;
					formattedResult.speed = res.ruleGroups.SPEED.score;
					formattedResult.responseCode = res.responseCode;

					let results: Array<any> = new Array<any>();

					for(let rule of Object.values(res.formattedResults.ruleResults)){
						results.push({
							'localizedRuleName':rule['localizedRuleName'],
							'ruleImpact':rule['ruleImpact'],
						});
					}
					formattedResult.results = results;

					site.googleResultMobile = formattedResult;

					resolve(true);
				},
				err => {
					site.googleResultMobile = false;
					resolve(false);
				}
			);
		});

		let promises_array: Array<any> = [p1, p2];

		Promise.all(promises_array).then(values => {
				site.status = SiteStatus.Loaded;
				if(this.sitesLength > this.index && queue){
					this.requestSite(this.Sites[this.index]);
				}
				this.index++;
		});
	}



}
